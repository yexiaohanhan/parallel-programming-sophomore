#include <sys/time.h>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <omp.h>
using namespace std;
const int N = 1000;
const int thread_num = 6;
const int chunksize = 1;
float m[N][N];
void m_reset()
{
	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < i; j++)
			m[i][j] = 0;
		m[i][i] = 1.0;
		for (int j = i + 1; j < N; j++)
			m[i][j] = rand();
	}
	for (int k = 0; k < N; k++)
		for (int i = k + 1; i < N; i++)
			for (int j = 0; j < N; j++)
				m[i][j] += m[k][j];
}
int main() {
	struct timeval start;
	struct timeval end;//clock
	float timecount;
	int comm_sz;
	int my_rank;

	MPI_Init(NULL, NULL);
	MPI_Comm_size(MPI_COMM_WORLD, &comm_sz);
	MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);

	if (rank == 0) {
		init_matrix();
	}
	start_time = MPI_Wtime();
	int task_num = rank < N% size ? N / size + 1 : N / size;
	// 0�Ž��̸�������ĳ�ʼ�ַ�����
	auto* buff = new float[task_num * N];
	if (rank == 0) {
		for (int p = 1; p < size; p++) {
			for (int i = p; i < N; i += size) {
				for (int j = 0; j < N; j++) {
					buff[i / size * N + j] = matrix[i][j];
				}
			}
			int count = p < N% size ? N / size + 1 : N / size;
			MPI_Send(buff, count * N, MPI_FLOAT, p, 0, MPI_COMM_WORLD);
		}
	}
	// ��0�Ž��̸�������Ľ��չ���
	else {
		MPI_Recv(&matrix[rank][0], task_num * N, MPI_FLOAT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		for (int i = 0; i < task_num; i++) {
			for (int j = 0; j < N; j++) {
				matrix[rank + i * size][j] = matrix[rank + i][j];
			}
		}
	}
	gettimeofday(&start, NULL);
	int i, j, k, num;
#pragma omp parallel if(1),num_threads(thread_num),private(num,i,j,k)
	//	for(int cy=0;cy<20;cy++){
	for (k = 0; k < N; k++)
	{
#pragma omp single
		if (r1 <= k && k <= r2) {
			for (j = k + 1; j < N; j++)
				m[k][j] = m[k][j] / m[k][k];
			m[k][k] = 1.0;
			for (num = my_rank + 1; num < comm_sz; num++)
				MPI_Send(&m[k][0], N, MPI_FLOAT, num, 1, MPI_COMM_WORLD);
		}
		else {
			if (k <= r2)
				MPI_Recv(&m[k][0], N, MPI_FLOAT, k / ((N - N % comm_sz) / comm_sz), 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
			//	break;
		}
		int r;
		if ((r1 <= k + 1) && (k + 1 <= r2))
			r = k + 1;
		if (k + 1 < r1)r = r1;
		if (k + 1 > r2)r = N;

#pragma omp for schedule(dynamic,chunksize)
		for (i = r; i <= r2; i++)
		{
			for (j = k + 1; j < N; j++)
				m[i][j] = m[i][j] - m[i][k] * m[k][j];
			m[i][k] = 0;
		}
	}
	//cout<<my_rank<<" "<<r1<<" "<<r2<<endl;
	if (my_rank != 0)
		MPI_Send(&m[r1][0], N * (r2 - r1 + 1), MPI_FLOAT, 0, 2, MPI_COMM_WORLD);
	else for (int q = 1; q < comm_sz; q++) {
		if (q != comm_sz - 1)
			MPI_Recv(&m[q * (N - N % comm_sz) / comm_sz][0], N * (r2 - r1 + 1), MPI_FLOAT, q, 2, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		else MPI_Recv(&m[q * (N - N % comm_sz) / comm_sz][0], N * (r2 - r1 + 1 + N % comm_sz), MPI_FLOAT, q, 2, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	}

	//	}

	/*	if(my_rank==0)
			for(int i=0;i<N;i++){
				for(int j=0;j<N;j++)
					cout<<m[i][j];
			cout<<endl;}*/

	MPI_Finalize();
	gettimeofday(&end, NULL);
	timecount += (end.tv_sec - start.tv_sec) * 1000000 + end.tv_usec - start.tv_usec;
	cout << timecount << endl;
	return 0;
}
