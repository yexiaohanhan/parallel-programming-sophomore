# mpi.sh
# !/bin/sh
# PBS -N mpi
# PBS -l nodes=2
pssh -h $PBS_NODEFILE mkdir -p /home/ss2112120 1>&2
scp master:/home/ss2112120/mpi /home/ss2112120
pscp -h $PBS_NODEFILE /home/ss2112120/mpi /home/ss2112120 1>&2
mpiexec -np 2 -machinefile $PBS_NODEFILE /home/ss2112120/mpi
